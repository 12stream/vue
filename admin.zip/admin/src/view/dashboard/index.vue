<template>
    <div class="dashboard-container">

    </div>
</template>
<script>
export default {
    data() {
        return {

        }
    }
}
</script>