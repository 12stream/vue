<template>
    <!-- <div :class="classObj" class="app-wrapper"> -->
    <div  class="app-wrapper">

    </div>
</template>
<script>
export default {
    computed: {
        // classObj() {
        //     return {
                
        //     }
        // }
    }
}
</script>